<template>
    <div class="flex items-center justify-center h-screen bg-gray-100">
        <router-view />
      <!-- <div class="bg-white p-6 rounded-lg shadow-lg w-96">
      </div> -->
    </div>
  </template>
  