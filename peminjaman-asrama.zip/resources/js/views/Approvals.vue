<template>
  <div>
    <ApprovalsList />
  </div>
</template>

<script>
import ApprovalsList from '../components/ApprovalsList.vue';

export default {
  components: {
    ApprovalsList,
  },
};
</script>