<template>
    <div>
      <ApplicationsList />
    </div>
  </template>
  
  <script>
  import ApplicationsList from '../components/ApplicationsList.vue';
  
  export default {
    components: {
      ApplicationsList,
    },
  };
  </script>