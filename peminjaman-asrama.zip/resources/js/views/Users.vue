<template>
  <div>
    <UsersList />
  </div>
</template>

<script>
import UsersList from '../components/UsersList.vue';

export default {
  components: {
    UsersList,
  },
};
</script>