<template>
    <div>
      <WhatsAppQR  />
    </div>
  </template>
  
  <script>
  import WhatsAppQR  from '../components/WhatsAppQR.vue';
  
  export default {
    components: {
      WhatsAppQR ,
    },
  };
  </script>