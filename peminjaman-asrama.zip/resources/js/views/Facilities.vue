<template>
    <div>
      <FacilitiesList />
    </div>
  </template>
  
  <script>
  import FacilitiesList from '../components/FacilitiesList.vue';
  
  export default {
    components: {
      FacilitiesList,
    },
  };
  </script>